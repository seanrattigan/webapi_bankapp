
package com.mycompany.bankApp.service;

/**
 *
 * @author Group-E
 */
public class CustomerService {
    
}
