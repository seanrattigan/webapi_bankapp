package com.mycompany.bankApp.service;

import com.mycompany.bankApp.database.DatabaseClass;
import com.mycompany.bankApp.model.Account;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 *
 * @author Group-E
 */
public class AccountService {
    
    private Map<Long, Account> accounts = DatabaseClass.getAccounts();
    
    public AccountService() {
        accounts.put(1L, new Account(1, 99999999, 111, 999.99));
    }
    
    public List<Account> getAllAccounts() {
        return new ArrayList<Account>(accounts.values());
    }
    
    public Account getAccount(long id) {
        return accounts.get(id);
    }
    
    public Account addAccount(Account account) {
        Random rand = new Random();
        account.setId(accounts.size() + 1);
        account.setAccNum(Integer.parseInt(String.format("%09d", rand.nextInt(1000000000))));
        accounts.put(account.getId(), account);
        return account;
    }
    
    public Account updateAccount(Account account) {
        if (account.getId() <= 0) {
            return null;
        }
        account.getSortCode();
        account.getAccNum();
        accounts.put(account.getId(), account);
        return account;
    }
    
    public Account removeAccount(long id) {
        return accounts.remove(id);
    }

}
