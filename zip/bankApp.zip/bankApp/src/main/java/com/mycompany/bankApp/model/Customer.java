
package com.mycompany.bankApp.model;

/**
 *
 * @author Group-E
 */
public class Customer {
    
}
