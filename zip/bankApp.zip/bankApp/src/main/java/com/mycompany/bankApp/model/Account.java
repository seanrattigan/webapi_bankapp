package com.mycompany.bankApp.model;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Group -E
 */
@XmlRootElement
public class Account {

    private long id;
    private long accNum;
    private long sortCode;
    private double curBalance;

    public Account() {
    }

    public Account(long id, long accNum, long sortCode, double curBalance) {
        this.id = id;
        this.accNum = accNum;
        this.sortCode = sortCode;
        this.curBalance = curBalance;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getAccNum() {
        return accNum;
    }

    public void setAccNum(long accNum) {
        this.accNum = accNum;
    }

    public long getSortCode() {
        return sortCode;
    }

    public void setSortCode(long sortCode) {
        this.sortCode = sortCode;
    }

    public double getCurBalance() {
        return curBalance;
    }

    public void setCurBalance(double curBalance) {
        this.curBalance = curBalance;
    }

}
