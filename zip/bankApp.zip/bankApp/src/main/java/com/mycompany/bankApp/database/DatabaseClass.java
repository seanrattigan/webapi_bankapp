package com.mycompany.bankApp.database;

import com.mycompany.bankApp.model.Account;
import com.mycompany.bankApp.model.Customer;
import com.mycompany.bankApp.model.Transaction;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Group-E
 */
public class DatabaseClass {

    public static Map<Long, Account> accounts = new HashMap();
    public static Map<Long, Customer> customer = new HashMap();
    public static Map<Long, Transaction> transaction = new HashMap();
    
    
    public static Map<Long, Account> getAccounts(){
        return accounts;
    }


}
